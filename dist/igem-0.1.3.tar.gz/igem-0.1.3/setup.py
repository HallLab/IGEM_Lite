# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['igem',
 'igem.epc',
 'igem.epc.clarite',
 'igem.epc.clarite.analyze',
 'igem.epc.clarite.describe',
 'igem.epc.clarite.load',
 'igem.epc.clarite.modify',
 'igem.epc.clarite.plot',
 'igem.epc.clarite.survey',
 'igem.ge',
 'igem.ge.db',
 'igem.ge.filter',
 'igem.ge.forms',
 'igem.ge.management',
 'igem.ge.management.commands',
 'igem.ge.management.commands.olds',
 'igem.ge.migrations',
 'igem.ge.tests',
 'igem.ge.utils',
 'igem.ge.views',
 'igem.omics',
 'igem.omics.migrations',
 'igem.src']

package_data = \
{'': ['*'],
 'igem.ge': ['templates/ge/pages/*', 'templates/ge/partials/*'],
 'igem.ge.tests': ['test_data_files/*', 'test_data_files/sync/*']}

install_requires = \
['clarite>=2.3,<3.0',
 'django-thread>=0.0.1,<0.0.2',
 'django>=4.1.5,<5.0.0',
 'requests>=2.28.2,<3.0.0']

setup_kwargs = {
    'name': 'igem',
    'version': '0.1.3',
    'description': '',
    'long_description': '',
    'author': 'Andre Rico',
    'author_email': '97684721+AndreRicoPSU@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.0,<3.11.0',
}


setup(**setup_kwargs)
