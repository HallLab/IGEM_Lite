# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['igem',
 'igem.epc',
 'igem.epc.clarite',
 'igem.epc.clarite.analyze',
 'igem.epc.clarite.describe',
 'igem.epc.clarite.load',
 'igem.epc.clarite.modify',
 'igem.epc.clarite.plot',
 'igem.epc.clarite.survey',
 'igem.ge',
 'igem.ge.db',
 'igem.ge.filter',
 'igem.ge.management',
 'igem.ge.management.commands',
 'igem.ge.management.commands.olds',
 'igem.ge.migrations',
 'igem.ge.utils',
 'igem.omics',
 'igem.omics.migrations',
 'igem.src']

package_data = \
{'': ['*'], 'igem': ['psa/*']}

install_requires = \
['clarite>=2.3,<3.0',
 'django-thread>=0.0.1,<0.0.2',
 'django>=4.1.5,<5.0.0',
 'requests>=2.28.2,<3.0.0']

setup_kwargs = {
    'name': 'igem',
    'version': '0.1.2',
    'description': '',
    'long_description': '',
    'author': 'Andre Rico',
    'author_email': '97684721+AndreRicoPSU@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.0,<3.11.0',
}


setup(**setup_kwargs)
