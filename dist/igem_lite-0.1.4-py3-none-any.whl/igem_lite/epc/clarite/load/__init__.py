from .load import from_csv, from_tsv

__all__ = ["from_csv", "from_tsv"]
